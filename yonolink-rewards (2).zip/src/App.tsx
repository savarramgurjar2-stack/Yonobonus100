import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Plus, 
  Copy, 
  ExternalLink, 
  Share2, 
  Check, 
  Flame, 
  Coins, 
  TrendingUp, 
  UserCheck, 
  RefreshCw, 
  Sliders, 
  Download, 
  Search, 
  Award, 
  ShieldCheck, 
  ChevronRight,
  Info,
  Gift,
  MousePointerClick,
  Lock,
  Trash2,
  LogOut,
  Settings,
  AlertCircle,
  Pencil
} from 'lucide-react';
import { INITIAL_APPS, RECENT_WINNERS } from './data';
import { YonoApp, CustomYonoLink, RecentWinner } from './types';
import { 
  getAppsFromDb, 
  saveAppToDb, 
  deleteAppFromDb, 
  getLinksFromDb, 
  saveLinkToDb, 
  deleteLinkFromDb, 
  incrementClickInDb, 
  clearAllLinksInDb 
} from './firebase';

export default function App() {
  // Database / Apps State (Synced with Firestore)
  const [apps, setApps] = useState<YonoApp[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Custom YonoLink Generator State
  const [referId, setReferId] = useState<string>('');
  const [selectedAppId, setSelectedAppId] = useState<string>('');
  const [customSuffix, setCustomSuffix] = useState<string>('');
  const [generatedLinks, setGeneratedLinks] = useState<CustomYonoLink[]>([]);
  const [justGenerated, setJustGenerated] = useState<CustomYonoLink | null>(null);

  // Advance Locked Panel State
  const [isAdvanceUnlocked, setIsAdvanceUnlocked] = useState<boolean>(false);
  const [advancePasswordInput, setAdvancePasswordInput] = useState<string>('');
  const [advanceGameName, setAdvanceGameName] = useState<string>('');
  const [advanceReferralCode, setAdvanceReferralCode] = useState<string>('');
  const [advanceAppLink, setAdvanceAppLink] = useState<string>('');

  // Admin Panel State
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  
  // Add App Form State
  const [newAppName, setNewAppName] = useState<string>('');
  const [newAppCategory, setNewAppCategory] = useState<string>('Rummy');
  const [newAppBonus, setNewAppBonus] = useState<number>(75); // strictly 50 to 100
  const [newAppUrl, setNewAppUrl] = useState<string>('');
  const [newAppRating, setNewAppRating] = useState<number>(4.8);
  const [newAppPlayers, setNewAppPlayers] = useState<string>('1.2M+');
  const [newAppIsPopular, setNewAppIsPopular] = useState<boolean>(false);
  const [editingApp, setEditingApp] = useState<YonoApp | null>(null);

  // Calculator State
  const [referralCount, setReferralCount] = useState<number>(10);
  const [avgBonus, setAvgBonus] = useState<number>(75); // strictly 50 to 100

  // UI Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedLinkId, setCopiedLinkId] = useState<string | null>(null);

  // Redirecting Mode States (for player redirects)
  const [isRedirectMode, setIsRedirectMode] = useState<boolean>(false);
  const [redirectApp, setRedirectApp] = useState<YonoApp | null>(null);
  const [redirectReferId, setRedirectReferId] = useState<string>('');
  const [redirectCountdown, setRedirectCountdown] = useState<number>(3);
  const [redirectError, setRedirectError] = useState<string | null>(null);
  const [isDbLoading, setIsDbLoading] = useState<boolean>(true);

  // Load database and saved links from Firestore on mount
  useEffect(() => {
    async function loadData() {
      // Check if this is a player redirect URL e.g. /play/yono-rummy/suffix?ref=123
      const pathname = window.location.pathname;
      const isRedirect = pathname.startsWith('/play/');

      if (isRedirect) {
        setIsRedirectMode(true);
        setIsDbLoading(true);
        
        try {
          const pathParts = pathname.split('/');
          const appId = pathParts[2] || '';
          const suffix = pathParts[3] || '';

          // Fetch fresh list from Firestore
          const fetchedApps = await getAppsFromDb();
          const fetchedLinks = await getLinksFromDb();

          const matchedApp = fetchedApps.find(a => a.id === appId);
          if (!matchedApp) {
            setRedirectError(`The game "${appId}" was not found in the verified database.`);
            setIsDbLoading(false);
            return;
          }

          setRedirectApp(matchedApp);

          // Get referral code from URL search query (?ref=...) or matching link
          const params = new URLSearchParams(window.location.search);
          let referIdFromUrl = params.get('ref') || '';

          if (!referIdFromUrl && suffix) {
            const matchingLink = fetchedLinks.find(l => l.gameId === appId && l.generatedLink.includes(suffix));
            if (matchingLink) {
              referIdFromUrl = matchingLink.referId;
            }
          }

          setRedirectReferId(referIdFromUrl || 'official');
          setIsDbLoading(false);

          // Increment clicks in database for this link if matching
          if (suffix) {
            const matchingLink = fetchedLinks.find(l => l.gameId === appId && l.generatedLink.includes(suffix));
            if (matchingLink) {
              incrementClickInDb(matchingLink.id);
            }
          }

          // Start the countdown
          let currentCount = 3;
          const timer = setInterval(() => {
            currentCount -= 1;
            setRedirectCountdown(currentCount);
            if (currentCount <= 0) {
              clearInterval(timer);
              
              // Direct download APK or play website redirection
              // If we have a query parameter, append it safely or redirect directly
              let redirectUrl = matchedApp.downloadUrl;
              if (referIdFromUrl) {
                if (redirectUrl.includes('?')) {
                  redirectUrl += `&ref=${referIdFromUrl}`;
                } else {
                  redirectUrl += `?ref=${referIdFromUrl}`;
                }
              }
              window.location.replace(redirectUrl);
            }
          }, 1000);

          return () => clearInterval(timer);
        } catch (e) {
          console.error('Redirect failed', e);
          setRedirectError('Failed to establish secure gateway. Please reload.');
          setIsDbLoading(false);
        }
      } else {
        // Normal Mode: Load normal directories
        setIsDbLoading(true);
        try {
          const fetchedApps = await getAppsFromDb();
          setApps(fetchedApps);
          if (fetchedApps.length > 0) {
            setSelectedAppId(fetchedApps[0].id);
          }

          const fetchedLinks = await getLinksFromDb();
          setGeneratedLinks(fetchedLinks);
        } catch (error) {
          console.error('Failed to load Firestore data', error);
        } finally {
          setIsDbLoading(false);
        }
      }
    }

    loadData();
  }, []);

  // Save Apps Helper
  const saveAppsToDb = async (updatedApps: YonoApp[]) => {
    setApps(updatedApps);
    // Persist backup to local
    localStorage.setItem('yono_custom_apps_db', JSON.stringify(updatedApps));
    if (updatedApps.length > 0 && !updatedApps.some(a => a.id === selectedAppId)) {
      setSelectedAppId(updatedApps[0].id);
    }
    // Sync to Firestore
    try {
      for (const app of updatedApps) {
        await saveAppToDb(app);
      }
    } catch (err) {
      console.error('Failed to sync updated apps to Firestore', err);
    }
  };

  // Save Links Helper (State updates only, direct saves handled in forms)
  const saveLinks = (links: CustomYonoLink[]) => {
    setGeneratedLinks(links);
    localStorage.setItem('yono_custom_links', JSON.stringify(links));
  };

  // Toast Trigger Helper
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Copy to Clipboard helper
  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLinkId(id);
    showToast('Copied to clipboard successfully!');
    setTimeout(() => setCopiedLinkId(null), 2000);
  };

  // Filter Categories
  const categories = ['All', 'Rummy', 'Slots', 'Arcade', 'Card', 'Predict'];

  const filteredApps = apps.filter(app => {
    const matchesCategory = selectedCategory === 'All' || app.category === selectedCategory;
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          app.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Handle Create Link Form Submission
  const handleCreateLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!referId.trim()) {
      showToast('Please enter a valid Referral ID or code!');
      return;
    }

    const appSelected = apps.find(a => a.id === selectedAppId);
    if (!appSelected) return;

    // Suffix generator
    const suffix = customSuffix.trim() 
      ? customSuffix.replace(/\s+/g, '-').toLowerCase() 
      : Math.random().toString(36).substring(2, 7);

    // Format final direct referral link
    const baseAppUrl = window.location.origin;
    const finalShortLink = `${baseAppUrl}/play/${appSelected.id}/${suffix}?ref=${referId}`;

    const newLink: CustomYonoLink = {
      id: Math.random().toString(36).substring(2, 9),
      originalUrl: appSelected.downloadUrl,
      referId: referId,
      gameId: appSelected.id,
      gameName: appSelected.name,
      generatedLink: finalShortLink,
      bonusAmount: appSelected.bonusAmount,
      clicks: 0,
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      })
    };

    try {
      await saveLinkToDb(newLink);
      setGeneratedLinks(prev => [newLink, ...prev]);
      setJustGenerated(newLink);
      showToast('✨ YonoLink created successfully and saved to cloud database!');
      setCustomSuffix('');
    } catch (err) {
      showToast('❌ Failed to save link to cloud.');
    }
  };

  // Advance Panel Handlers
  const handleUnlockAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    if (advancePasswordInput === '@om764501') {
      setIsAdvanceUnlocked(true);
      showToast('🔓 Advance features unlocked!');
      setAdvancePasswordInput('');
    } else {
      showToast('❌ Incorrect password! Please try again.');
    }
  };

  const handleAdvanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!advanceGameName.trim() || !advanceReferralCode.trim() || !advanceAppLink.trim()) {
      showToast('Please fill in all three fields!');
      return;
    }

    const trimmedGameName = advanceGameName.trim();
    const trimmedReferCode = advanceReferralCode.trim();
    const trimmedAppLink = advanceAppLink.trim();

    // Create a new app entry in the verified database
    const newAppId = 'yono-' + Math.random().toString(36).substring(2, 9);
    const newApp: YonoApp = {
      id: newAppId,
      name: trimmedGameName,
      category: 'Rummy', // Default category
      bonusAmount: 75, // Default/Average bonus
      downloadUrl: trimmedAppLink,
      rating: 4.8,
      playersCount: '1.2M+',
      isPopular: true
    };

    // Generate Custom Short Link for this new app immediately
    const suffix = Math.random().toString(36).substring(2, 7);
    const baseAppUrl = window.location.origin;
    const finalShortLink = `${baseAppUrl}/play/${newApp.id}/${suffix}?ref=${trimmedReferCode}`;

    const newLink: CustomYonoLink = {
      id: Math.random().toString(36).substring(2, 9),
      originalUrl: newApp.downloadUrl,
      referId: trimmedReferCode,
      gameId: newApp.id,
      gameName: newApp.name,
      generatedLink: finalShortLink,
      bonusAmount: newApp.bonusAmount,
      clicks: 0,
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      })
    };

    try {
      // Save App & Link to Firestore
      await saveAppToDb(newApp);
      await saveLinkToDb(newLink);

      // Update local states
      setApps(prev => [...prev, newApp]);
      setGeneratedLinks(prev => [newLink, ...prev]);
      setJustGenerated(newLink);
      showToast(`✨ ${newApp.name} added to database & link generated!`);

      // Reset Form
      setAdvanceGameName('');
      setAdvanceReferralCode('');
      setAdvanceAppLink('');
    } catch (err) {
      showToast('❌ Failed to save new game to cloud.');
    }
  };

  // Admin Auth Handler
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === '@om764501') {
      setIsAdminLoggedIn(true);
      showToast('🔑 Welcome Back Admin! Access Granted.');
      setAdminPassword('');
    } else {
      showToast('❌ Incorrect password! Please try again.');
    }
  };

  // Admin Create New App / Edit App
  const handleAddNewApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim() || !newAppUrl.trim()) {
      showToast('Please fill out all required fields!');
      return;
    }

    // Validate Bonus Range
    const validatedBonus = Math.min(Math.max(newAppBonus, 50), 100);

    if (editingApp) {
      // Editing an existing app
      const updatedApp: YonoApp = {
        ...editingApp,
        name: newAppName,
        category: newAppCategory,
        bonusAmount: validatedBonus,
        downloadUrl: newAppUrl,
        rating: parseFloat(newAppRating.toFixed(1)),
        playersCount: newAppPlayers,
        isPopular: newAppIsPopular
      };

      try {
        await saveAppToDb(updatedApp);
        setApps(prev => prev.map(app => app.id === editingApp.id ? updatedApp : app));
        showToast(`✅ Successfully updated ${newAppName} in cloud!`);

        // Reset Form & Editing State
        setEditingApp(null);
        setNewAppName('');
        setNewAppUrl('');
        setNewAppRating(4.8);
        setNewAppPlayers('1.2M+');
        setNewAppIsPopular(false);
      } catch (err) {
        showToast('❌ Failed to update app in cloud database.');
      }
    } else {
      // Adding a new app
      const newApp: YonoApp = {
        id: 'yono-' + Math.random().toString(36).substring(2, 9),
        name: newAppName,
        category: newAppCategory,
        bonusAmount: validatedBonus,
        downloadUrl: newAppUrl,
        rating: parseFloat(newAppRating.toFixed(1)),
        playersCount: newAppPlayers,
        isPopular: newAppIsPopular
      };

      try {
        await saveAppToDb(newApp);
        setApps(prev => [...prev, newApp]);
        showToast(`✅ Successfully added ${newAppName} to cloud!`);

        // Reset Form
        setNewAppName('');
        setNewAppUrl('');
        setNewAppRating(4.8);
        setNewAppPlayers('1.2M+');
        setNewAppIsPopular(false);
      } catch (err) {
        showToast('❌ Failed to add app to cloud database.');
      }
    }
  };

  // Admin Delete App
  const handleDeleteApp = async (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete ${name}?`)) {
      try {
        await deleteAppFromDb(id);
        setApps(prev => prev.filter(app => app.id !== id));
        showToast(`🗑️ Removed ${name} from cloud database.`);
      } catch (err) {
        showToast('❌ Failed to delete app from cloud database.');
      }
    }
  };

  // Simulate link visit & trigger immediate direct download/redirect for correct download behavior
  const handleSimulateClickAndDownload = async (link: CustomYonoLink) => {
    // Update click count
    try {
      await incrementClickInDb(link.id);
      setGeneratedLinks(prev => prev.map(l => {
        if (l.id === link.id) {
          return { ...l, clicks: l.clicks + 1 };
        }
        return l;
      }));
    } catch (err) {
      console.error(err);
    }

    showToast('🚀 Redirecting & initiating secure direct download...');
    setTimeout(() => {
      window.open(link.originalUrl, '_blank');
    }, 800);
  };

  if (isRedirectMode) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans">
        {/* Decorative background radial light */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-md w-full bg-slate-900 border border-slate-800/80 p-8 rounded-3xl flex flex-col items-center text-center gap-6 shadow-2xl relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <div className="bg-indigo-600 p-2 rounded-xl border border-indigo-500/30 shadow-lg shadow-indigo-500/20">
              <Coins className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-extrabold text-xl tracking-tight text-white">yonolink</span>
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">Gateway</span>
          </div>

          {isDbLoading ? (
            <div className="flex flex-col items-center gap-4 py-8">
              <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
              <p className="text-sm text-slate-400 font-medium">Establishing secure gateway connection...</p>
            </div>
          ) : redirectError ? (
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="bg-red-500/10 text-red-500 p-4 rounded-full border border-red-500/20">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h3 className="font-display font-extrabold text-lg text-slate-100">Connection Error</h3>
              <p className="text-xs text-slate-400 leading-relaxed max-w-xs">{redirectError}</p>
              <a
                href="/"
                className="mt-4 px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-all border border-slate-700"
              >
                Go to Homepage
              </a>
            </div>
          ) : redirectApp ? (
            <div className="w-full flex flex-col gap-6">
              <div className="bg-slate-950 border border-slate-800/80 p-5 rounded-2xl flex flex-col gap-3 relative">
                <span className="absolute top-2 right-2 flex items-center gap-1 text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold">
                  <ShieldCheck className="w-3 h-3" />
                  <span>VERIFIED</span>
                </span>
                
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold self-start">Target Application</span>
                <h2 className="text-xl font-extrabold text-slate-100 text-left">{redirectApp.name}</h2>
                
                <div className="flex items-center justify-between border-t border-slate-800/60 pt-3 mt-1 text-xs">
                  <span className="text-slate-400">Guaranteed Bonus:</span>
                  <span className="text-emerald-400 font-extrabold text-sm bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                    ₹{redirectApp.bonusAmount} Cash
                  </span>
                </div>
              </div>

              {/* Countdown / Status circle */}
              <div className="flex flex-col items-center gap-3 my-2">
                <div className="relative w-20 h-20 flex items-center justify-center">
                  <div className="absolute inset-0 border-4 border-slate-800 rounded-full" />
                  <div className="absolute inset-0 border-4 border-indigo-500 rounded-full animate-pulse" style={{ borderTopColor: 'transparent', borderRightColor: 'transparent' }} />
                  <span className="text-3xl font-extrabold font-mono text-indigo-400">{redirectCountdown}</span>
                </div>
                <p className="text-sm text-slate-300 font-medium">Securing sign-up bonus parameters...</p>
                <p className="text-[11px] text-slate-500 font-mono">Referral Code Applied: <span className="text-indigo-400 font-bold">{redirectReferId}</span></p>
              </div>

              <div className="h-[1px] bg-slate-800/60" />

              <div className="flex flex-col gap-3">
                <a
                  href={redirectApp.downloadUrl + (redirectReferId ? `${redirectApp.downloadUrl.includes('?') ? '&' : '?'}ref=${redirectReferId}` : '')}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold py-3 text-sm shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>Start Download Now</span>
                </a>
                <p className="text-[10px] text-slate-500 leading-normal">
                  If you are not redirected automatically in {redirectCountdown} seconds, please tap the button above to manually trigger direct download.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 py-8">
              <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
              <p className="text-sm text-slate-400 font-medium">Retrieving gateway profile...</p>
            </div>
          )}

          <div className="flex items-center gap-4 justify-center text-[10px] text-slate-500 border-t border-slate-800/40 pt-4 w-full font-medium">
            <span className="flex items-center gap-1">🔒 256-Bit SSL</span>
            <span>•</span>
            <span className="flex items-center gap-1">🛡️ Anti-Fraud Verified</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans relative overflow-x-hidden pb-12">
      {/* Background Radial Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] bg-gradient-to-b from-indigo-100/40 via-transparent to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Floating Notification Toast */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 left-1/2 z-50 bg-slate-900 text-white px-6 py-3 rounded-full shadow-xl shadow-slate-200/50 border border-slate-800/20 flex items-center gap-2 font-medium"
          >
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header section */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl shadow-lg shadow-indigo-100 border border-indigo-400/20">
              <Coins className="w-6 h-6 text-white stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-extrabold text-2xl tracking-tight text-slate-900">
                  yonolink
                </span>
                <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  Bonus Hub
                </span>
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Earn ₹50 - ₹100 Referrals</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm text-slate-600 font-medium">
            <a href="#apps" className="hover:text-indigo-600 transition-colors">Yono App List</a>
            <a href="#advance" className="hover:text-indigo-600 transition-colors">Advance</a>
            <a href="#calculator" className="hover:text-indigo-600 transition-colors">Earnings Calc</a>
            <button 
              onClick={() => setIsAdminMode(!isAdminMode)} 
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
                isAdminMode 
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/10' 
                  : 'bg-slate-100 text-slate-700 hover:text-indigo-600 border-slate-200'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-mono text-slate-600 font-bold tracking-wider">14,281 ACTIVE USERS</span>
          </div>
        </div>
      </header>

      {/* Ticker / Running feed of bonus winners */}
      <div className="bg-white border-b border-slate-200 py-3 overflow-hidden">
        <div className="max-w-6xl mx-auto px-6 flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5 text-indigo-600 font-bold shrink-0 uppercase tracking-wider">
            <Flame className="w-3.5 h-3.5 animate-bounce" />
            <span>LIVE CLAIM FEED:</span>
          </div>
          <div className="flex-1 overflow-hidden relative h-5">
            <div className="absolute inset-0 flex items-center gap-8 animate-[marquee_25s_linear_infinite] whitespace-nowrap">
              {RECENT_WINNERS.map((winner, index) => (
                <div key={`${winner.id}-${index}`} className="inline-flex items-center gap-1.5 text-slate-600 font-medium">
                  <span className="text-indigo-600 font-semibold">{winner.username}</span>
                  <span>claimed</span>
                  <span className="text-emerald-700 font-bold bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded">
                    ₹{winner.bonus} Bonus
                  </span>
                  <span>on</span>
                  <span className="text-slate-800 font-semibold">{winner.appName}</span>
                  <span className="text-[10px] text-slate-400 font-normal">({winner.time})</span>
                  <span className="text-slate-300 mx-1">•</span>
                </div>
              ))}
              {/* Duplicate for infinite loop visual */}
              {RECENT_WINNERS.map((winner, index) => (
                <div key={`${winner.id}-dup-${index}`} className="inline-flex items-center gap-1.5 text-slate-600 font-medium">
                  <span className="text-indigo-600 font-semibold">{winner.username}</span>
                  <span>claimed</span>
                  <span className="text-emerald-700 font-bold bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded">
                    ₹{winner.bonus} Bonus
                  </span>
                  <span>on</span>
                  <span className="text-slate-800 font-semibold">{winner.appName}</span>
                  <span className="text-[10px] text-slate-400 font-normal">({winner.time})</span>
                  <span className="text-slate-300 mx-1">•</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-6xl w-full mx-auto px-6 py-12 flex-1 flex flex-col gap-10">
        
        {/* ADMIN MODE OVERLAY PANEL */}
        <AnimatePresence>
          {isAdminMode && (
            <motion.section 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-200 rounded-3xl p-6 lg:p-8 relative shadow-xl">
                <div className="flex items-center justify-between border-b border-amber-200 pb-4 mb-6">
                  <div className="flex items-center gap-2.5">
                    <div className="bg-amber-500 text-slate-950 p-2 rounded-xl">
                      <Settings className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="font-display font-extrabold text-xl text-slate-950">YonoLink Admin Console</h2>
                      <p className="text-xs text-amber-800 font-medium">Add, delete or update verified apps, targets, and parameters.</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      setIsAdminLoggedIn(false);
                      setIsAdminMode(false);
                      showToast('Logged out of admin panel.');
                    }} 
                    className="flex items-center gap-1 text-xs font-bold text-amber-900 hover:text-amber-700 underline"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Close Panel</span>
                  </button>
                </div>

                {!isAdminLoggedIn ? (
                  /* Admin Password Login Form */
                  <form onSubmit={handleAdminLogin} className="max-w-md mx-auto bg-white border border-amber-200 p-6 rounded-2xl shadow-md flex flex-col gap-4">
                    <div className="text-center">
                      <Lock className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                      <h3 className="font-display font-bold text-slate-900">Unlock Administrator Panel</h3>
                      <p className="text-xs text-slate-500 mt-0.5">Please enter the correct password to continue</p>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Admin Password</label>
                      <input
                        type="password"
                        required
                        placeholder="Enter password"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2.5 px-4 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-amber-500/20 font-mono"
                      />
                    </div>

                    <button 
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 px-4 rounded-xl shadow-lg shadow-amber-500/10 transition-all flex items-center justify-center gap-2"
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>Authenticate Credentials</span>
                    </button>
                  </form>
                ) : (
                  /* Admin Actions & Management */
                  <div className="grid md:grid-cols-12 gap-8 items-start">
                    
                    {/* Add / Edit Application Form */}
                    <div className="md:col-span-5 bg-white p-6 rounded-2xl shadow-md border border-slate-200 flex flex-col gap-4">
                      <h3 className="font-display font-bold text-slate-950 flex items-center gap-1.5">
                        {editingApp ? (
                          <>
                            <Pencil className="w-4 h-4 text-indigo-600 animate-pulse" />
                            <span>Edit Yono Application</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-4 h-4 text-indigo-600" />
                            <span>Add New Yono Application</span>
                          </>
                        )}
                      </h3>

                      <form onSubmit={handleAddNewApp} className="flex flex-col gap-4 text-xs">
                        <div className="flex flex-col gap-1">
                          <label className="font-bold text-slate-700">Application Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Yono Cash Slots"
                            value={newAppName}
                            onChange={(e) => setNewAppName(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none focus:border-indigo-500 font-medium"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="flex flex-col gap-1">
                            <label className="font-bold text-slate-700">Category</label>
                            <select
                              value={newAppCategory}
                              onChange={(e) => setNewAppCategory(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none font-medium"
                            >
                              <option value="Rummy">Rummy</option>
                              <option value="Slots">Slots</option>
                              <option value="Arcade">Arcade</option>
                              <option value="Card">Card</option>
                              <option value="Predict">Predict</option>
                            </select>
                          </div>

                          <div className="flex flex-col gap-1">
                            <label className="font-bold text-slate-700">Bonus Amount (₹50-100)</label>
                            <input
                              type="number"
                              min="50"
                              max="100"
                              required
                              value={newAppBonus}
                              onChange={(e) => setNewAppBonus(parseInt(e.target.value) || 75)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none focus:border-indigo-500 font-mono font-semibold"
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-1">
                          <label className="font-bold text-slate-700">Direct Download APK / Website URL</label>
                          <input
                            type="url"
                            required
                            placeholder="https://official-yono-url.com/apk"
                            value={newAppUrl}
                            onChange={(e) => setNewAppUrl(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none focus:border-indigo-500 font-mono text-[11px]"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="flex flex-col gap-1">
                            <label className="font-bold text-slate-700">Rating (out of 5)</label>
                            <input
                              type="number"
                              step="0.1"
                              min="1"
                              max="5"
                              required
                              value={newAppRating}
                              onChange={(e) => setNewAppRating(parseFloat(e.target.value) || 4.8)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none font-mono"
                            />
                          </div>

                          <div className="flex flex-col gap-1">
                            <label className="font-bold text-slate-700">Active Players</label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. 1.2M+"
                              value={newAppPlayers}
                              onChange={(e) => setNewAppPlayers(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 outline-none font-medium"
                            />
                          </div>
                        </div>

                        <div className="flex items-center gap-2 py-1">
                          <input
                            type="checkbox"
                            id="isPopular"
                            checked={newAppIsPopular}
                            onChange={(e) => setNewAppIsPopular(e.target.checked)}
                            className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                          />
                          <label htmlFor="isPopular" className="font-bold text-slate-700 cursor-pointer">
                            Mark as Popular / "Hot" Badge
                          </label>
                        </div>

                        <div className="flex gap-2">
                          {editingApp && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingApp(null);
                                setNewAppName('');
                                setNewAppUrl('');
                                setNewAppRating(4.8);
                                setNewAppPlayers('1.2M+');
                                setNewAppIsPopular(false);
                                showToast('Cancelled editing App.');
                              }}
                              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-lg transition-all"
                            >
                              Cancel
                            </button>
                          )}
                          <button
                            type="submit"
                            className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center gap-1.5"
                          >
                            {editingApp ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                            <span>{editingApp ? 'Update App' : 'Insert Into Database'}</span>
                          </button>
                        </div>
                      </form>
                    </div>

                    {/* Manage Database Apps Grid */}
                    <div className="md:col-span-7 bg-white p-6 rounded-2xl shadow-md border border-slate-200 flex flex-col gap-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-display font-bold text-slate-950 flex items-center gap-1.5">
                          <Sliders className="w-4 h-4 text-amber-500" />
                          <span>Database Applications ({apps.length})</span>
                        </h3>
                        <button 
                          onClick={() => {
                            if (confirm('Reset to initial default apps list? This overrides any custom modifications.')) {
                              saveAppsToDb(INITIAL_APPS);
                              showToast('Database reset to defaults.');
                            }
                          }}
                          className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider hover:underline"
                        >
                          Reset Defaults
                        </button>
                      </div>

                      <div className="overflow-y-auto max-h-[350px] divide-y divide-slate-100 pr-1">
                        {apps.map(app => (
                          <div key={app.id} className="py-3 flex items-center justify-between gap-4">
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-semibold text-slate-900 text-sm">{app.name}</span>
                                <span className="text-[9px] bg-slate-100 text-slate-600 border px-1.5 py-0.2 rounded font-bold uppercase">{app.category}</span>
                              </div>
                              <div className="flex items-center gap-4 text-[10px] text-slate-500 mt-0.5">
                                <span className="text-indigo-600 font-bold">Guaranteed Bonus: ₹{app.bonusAmount}</span>
                                <span>•</span>
                                <span className="truncate max-w-[240px] block font-mono">{app.downloadUrl}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => {
                                  setEditingApp(app);
                                  setNewAppName(app.name);
                                  setNewAppCategory(app.category);
                                  setNewAppBonus(app.bonusAmount);
                                  setNewAppUrl(app.downloadUrl);
                                  setNewAppRating(app.rating);
                                  setNewAppPlayers(app.playersCount || '1.2M+');
                                  setNewAppIsPopular(app.isPopular || false);
                                  showToast(`📝 Editing "${app.name}"... form loaded!`);
                                }}
                                className="text-indigo-600 hover:text-indigo-800 p-2 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-all"
                                title="Edit App"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteApp(app.id, app.name)}
                                className="text-red-600 hover:text-red-800 p-2 bg-red-50 hover:bg-red-100 rounded-lg transition-all"
                                title="Delete App"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                )}
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* HERO SECTION / VALUE PROP */}
        <section className="grid lg:grid-cols-12 gap-10 items-center bg-white border border-slate-200/80 rounded-3xl p-8 lg:p-10 relative overflow-hidden shadow-2xl shadow-slate-100">
          <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
          
          <div className="lg:col-span-7 flex flex-col gap-5 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 self-center lg:self-start bg-indigo-50 text-indigo-700 border border-indigo-200/60 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Official Yono Referral Link Optimizer</span>
            </div>
            
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-slate-950">
              Download app and <br />
              <span className="text-indigo-600">earn bonus.</span>
            </h1>
            
            <p className="text-slate-600 text-base md:text-lg max-w-xl leading-relaxed">
              Join the Yonolink network today. Generate optimized custom referral links, share them with your audience, and receive a guaranteed bonus of <strong className="text-slate-900">₹50–₹100</strong> for every successful activation.
            </p>

            <div className="grid grid-cols-3 gap-4 mt-2 max-w-md mx-auto lg:mx-0">
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center shadow-sm">
                <span className="block text-xl font-extrabold text-indigo-600">₹50-100</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Sign Up Bonus</span>
              </div>
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center shadow-sm">
                <span className="block text-xl font-extrabold text-slate-900">6+ Apps</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Verified Games</span>
              </div>
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center shadow-sm">
                <span className="block text-xl font-extrabold text-emerald-600">100%</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Direct Payout</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mt-4 justify-center lg:justify-start">
              <a 
                href="#advance" 
                className="px-8 py-4 bg-slate-950 text-white rounded-xl font-bold shadow-lg shadow-slate-200 hover:bg-slate-800 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <Sliders className="w-4 h-4 text-indigo-400" />
                <span>Advance</span>
              </a>
              <a 
                href="#apps" 
                className="px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-xl font-bold hover:bg-slate-50 shadow-sm transition-all flex items-center justify-center gap-2 text-sm"
              >
                <Download className="w-4 h-4 text-indigo-600" />
                <span>Download Games List</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col items-center justify-center bg-slate-50 border border-slate-100 p-8 rounded-3xl relative">
            <div className="absolute top-2 right-2 flex items-center gap-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200/50 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
              <ShieldCheck className="w-3 h-3 animate-pulse" />
              <span>100% Verified</span>
            </div>

            <h3 className="font-display font-extrabold text-lg text-center mb-1.5 text-slate-900">
              Guaranteed Payout
            </h3>
            <p className="text-slate-500 text-xs text-center mb-6 font-medium leading-relaxed">
              Every app added to the Yonolink registry undergoes automated safety audits to verify direct server connections and secure signup bonus payouts.
            </p>

            <div className="w-full flex flex-col gap-4">
              <div className="bg-white border border-slate-200 p-4 rounded-2xl flex items-start gap-3.5 shadow-sm">
                <div className="bg-indigo-50 p-2 rounded-lg text-indigo-600">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Secure Direct Referral downloads</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">
                    Users instantly fetch secure register-capable URLs configured to initiate APK downlinks perfectly.
                  </p>
                </div>
              </div>

              <div className="bg-white border border-slate-200 p-4 rounded-2xl flex items-start gap-3.5 shadow-sm">
                <div className="bg-emerald-50 p-2 rounded-lg text-emerald-600">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Highest Active Referral Conversion</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">
                    Redirects prompt players with beautifully paired claims on our network with up to 2.5x traffic multiplier rewards.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 1: ADVANCE (FORM) */}
        <section id="advance" className="grid lg:grid-cols-12 gap-8 items-start">
          
          <div className="lg:col-span-6 bg-white border border-slate-200 p-8 rounded-3xl flex flex-col gap-6 relative shadow-xl shadow-slate-100">
            <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-600 animate-pulse" />
                <h2 className="font-display font-extrabold text-xl text-slate-900">Advance</h2>
              </div>
              {isAdvanceUnlocked && (
                <button 
                  onClick={() => {
                    setIsAdvanceUnlocked(false);
                    showToast('Logged out of Advance panel.');
                  }}
                  className="text-xs text-slate-400 hover:text-indigo-600 transition-colors font-semibold flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Lock Panel</span>
                </button>
              )}
            </div>

            {!isAdvanceUnlocked ? (
              <form onSubmit={handleUnlockAdvance} className="flex flex-col gap-5 py-4">
                <div className="text-center py-2">
                  <div className="bg-indigo-50 text-indigo-600 p-3 rounded-2xl w-12 h-12 flex items-center justify-center mx-auto mb-3 border border-indigo-100">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h3 className="font-display font-extrabold text-lg text-slate-900">Advance Section Locked</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
                    Please enter the authorization key to unlock custom game creation and smart referral links.
                  </p>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Security Password</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={advancePasswordInput}
                    onChange={(e) => setAdvancePasswordInput(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white rounded-xl font-bold py-3 hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Access Advance Panel</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleAdvanceSubmit} className="flex flex-col gap-5">
                <div className="flex flex-col gap-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                    Game Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter custom game name (e.g. Yono Star)"
                    value={advanceGameName}
                    onChange={(e) => setAdvanceGameName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                    Referral Code / ID
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter referral code or number"
                    value={advanceReferralCode}
                    onChange={(e) => setAdvanceReferralCode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">
                    App URL / Link
                  </label>
                  <input
                    type="url"
                    required
                    placeholder="Paste original app URL or download link"
                    value={advanceAppLink}
                    onChange={(e) => setAdvanceAppLink(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white rounded-xl font-bold text-lg hover:bg-indigo-700 shadow-lg shadow-indigo-200 py-3.5 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Sparkles className="w-5 h-5 text-amber-300 fill-amber-300/30" />
                  <span>Add Game & Generate Link</span>
                </button>
              </form>
            )}

            <div className="bg-indigo-50/60 border border-indigo-100 p-4 rounded-2xl flex items-start gap-2.5 text-xs text-indigo-900 shadow-sm">
              <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed text-indigo-950 font-medium">
                Once unlocked, adding a new game injects it into the verified directory and outputs an instant high-conversion YonoLink with custom payouts.
              </p>
            </div>
          </div>

          {/* GENERATION STATUS / RECENTLY GENERATED */}
          <div className="lg:col-span-6 flex flex-col gap-5">
            
            {justGenerated ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white border-2 border-emerald-500/20 rounded-3xl p-8 flex flex-col gap-4 relative overflow-hidden shadow-2xl shadow-slate-100"
              >
                <div className="absolute top-0 right-0 bg-emerald-500/10 text-emerald-700 border-b border-l border-emerald-500/20 text-[10px] font-bold px-4 py-2 rounded-bl-2xl uppercase tracking-wider">
                  Success Generated
                </div>

                <div>
                  <h3 className="font-display font-extrabold text-xl text-slate-950 flex items-center gap-1.5">
                    <Check className="w-5 h-5 text-emerald-500" />
                    <span>Your YonoLink is Live!</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">Copy and share this link to claim bonuses</p>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-col gap-2.5 font-mono">
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>TARGET GAME</span>
                    <span className="text-slate-900 font-bold">{justGenerated.gameName}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>BONUS PROMISED</span>
                    <span className="text-indigo-600 font-extrabold bg-indigo-50 px-2.5 py-0.5 rounded border border-indigo-100">
                      ₹{justGenerated.bonusAmount} Cash
                    </span>
                  </div>
                  <div className="h-[1px] bg-slate-200 my-1" />
                  <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-indigo-600 text-xs truncate select-all font-semibold">{justGenerated.generatedLink}</span>
                    <button
                      onClick={() => copyToClipboard(justGenerated.generatedLink, justGenerated.id)}
                      className="shrink-0 bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-lg transition-colors flex items-center justify-center"
                      title="Copy YonoLink"
                    >
                      {copiedLinkId === justGenerated.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => handleSimulateClickAndDownload(justGenerated)}
                    className="flex-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 py-3 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Test & Download APK</span>
                  </button>
                  <button
                    onClick={() => {
                      copyToClipboard(justGenerated.generatedLink, justGenerated.id);
                    }}
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-3 rounded-xl text-xs font-bold shadow-md shadow-indigo-100 transition-all flex items-center justify-center gap-1.5"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share & Promote</span>
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="bg-white border-2 border-slate-200 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center text-center h-full min-h-[240px] shadow-sm">
                <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center mb-3">
                  <Plus className="w-5 h-5 text-slate-400" />
                </div>
                <h3 className="font-display font-bold text-sm text-slate-800">No New Link Generated Yet</h3>
                <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed font-medium">
                  Unlock the Advance panel on the left to add a game and generate a smart referral redirect link instantly.
                </p>
              </div>
            )}

            {/* QUICK STATS PANEL */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white border border-slate-200 p-4 rounded-2xl flex items-center gap-3.5 shadow-sm">
                <div className="bg-indigo-50 p-2.5 rounded-xl border border-indigo-100">
                  <UserCheck className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-widest">Avg Referral Rate</span>
                  <span className="text-base font-extrabold text-slate-900">₹82 / user</span>
                </div>
              </div>
              <div className="bg-white border border-slate-200 p-4 rounded-2xl flex items-center gap-3.5 shadow-sm">
                <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-widest">Estimated Bonus</span>
                  <span className="text-base font-extrabold text-slate-900">₹50 - ₹100</span>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* SECTION 2: VERIFIED YONOLINK DOWNLOAD DIRECTORY */}
        <section id="apps" className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Award className="w-5 h-5 text-indigo-600" />
                <h2 className="font-display font-extrabold text-xl text-slate-900">Provided Yono Websites & Downloads</h2>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Claim your sign-up bonus instantly. All links are tested and guarantee rewards of ₹50 - ₹100 on verified register.
              </p>
            </div>

            {/* Search Bar inside Directory */}
            <div className="relative max-w-xs w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search Yono Apps..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-800 outline-none focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
              />
            </div>
          </div>

          {/* Filter Categories Tabs */}
          <div className="flex flex-wrap gap-1.5 bg-slate-100 border border-slate-200 p-1 rounded-xl self-start">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === cat 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/50' 
                    : 'text-slate-500 hover:text-slate-950 hover:bg-slate-200/50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Apps Cards Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredApps.map((app) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  key={app.id}
                  className="bg-white border border-slate-100 shadow-lg shadow-slate-100/80 hover:shadow-xl hover:border-slate-200/80 rounded-3xl p-6 flex flex-col gap-4 relative group transition-all duration-300"
                >
                  {/* Category Pill */}
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] bg-slate-50 text-slate-500 border border-slate-200 px-2.5 py-1 rounded-md font-bold uppercase tracking-wider">
                      {app.category}
                    </span>
                    <div className="flex items-center gap-1 text-[11px] font-bold text-indigo-600">
                      <span>★</span>
                      <span>{app.rating.toFixed(1)}</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-display font-extrabold text-base text-slate-950 group-hover:text-indigo-600 transition-colors flex items-center gap-1.5">
                      {app.name}
                      {app.isPopular && (
                        <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 text-[9px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider">Hot</span>
                      )}
                    </h3>
                    <p className="text-slate-400 text-[11px] font-semibold mt-0.5">Downloads: {app.playersCount} players</p>
                  </div>

                  {/* Guaranteed Bonus Badge */}
                  <div className="bg-slate-50 border border-slate-200/80 px-3 py-3 rounded-2xl flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-bold">Verified Sign-up Reward</span>
                    <span className="text-indigo-600 font-extrabold text-sm bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                      ₹{app.bonusAmount} Cash
                    </span>
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => copyToClipboard(app.downloadUrl, app.id)}
                      className="bg-slate-50 hover:bg-slate-100 text-slate-600 p-2.5 rounded-xl border border-slate-200 transition-colors flex items-center justify-center shrink-0"
                      title="Copy Direct Link"
                    >
                      {copiedLinkId === app.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <a
                      href={app.downloadUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-slate-950 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md shadow-slate-200"
                    >
                      <Download className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Download App</span>
                    </a>
                    <button
                      onClick={() => {
                        setSelectedAppId(app.id);
                        document.getElementById('creator')?.scrollIntoView({ behavior: 'smooth' });
                        showToast(`Selected ${app.name} in Generator`);
                      }}
                      className="bg-indigo-50 hover:bg-indigo-100 text-indigo-600 p-2.5 rounded-xl border border-indigo-100 transition-all flex items-center justify-center shrink-0"
                      title="Generate custom link for this game"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {filteredApps.length === 0 && (
              <div className="col-span-full bg-white border border-slate-200 border-dashed rounded-3xl p-10 text-center flex flex-col items-center justify-center shadow-sm">
                <p className="text-sm text-slate-500 font-medium">No applications matched your search filters.</p>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
                  className="mt-2 text-xs text-indigo-600 hover:underline font-bold"
                >
                  Clear search filters
                </button>
              </div>
            )}
          </div>
        </section>

        {/* SECTION 3: MY GENERATED LINKS DASHBOARD */}
        <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xl shadow-slate-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sliders className="w-5 h-5 text-indigo-600" />
                <h3 className="font-display font-extrabold text-lg text-slate-900">My Generated Links</h3>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Track and test the links you have created on this browser. Persisted locally.
              </p>
            </div>
            
            {generatedLinks.length > 0 && (
              <button
                onClick={async () => {
                  if (confirm('Are you sure you want to clear your link history?')) {
                    try {
                      await clearAllLinksInDb(generatedLinks);
                      saveLinks([]);
                      showToast('Cleared cloud link history!');
                    } catch (err) {
                      showToast('❌ Failed to clear history.');
                    }
                  }
                }}
                className="text-[10px] text-red-600 hover:text-red-500 transition-colors uppercase font-bold tracking-widest"
              >
                Clear History
              </button>
            )}
          </div>

          {generatedLinks.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 uppercase tracking-widest font-bold text-[10px]">
                    <th className="py-3.5 px-4">Game / Target</th>
                    <th className="py-3.5 px-4">Generated YonoLink</th>
                    <th className="py-3.5 px-4">Refer Code</th>
                    <th className="py-3.5 px-4">Guaranteed Bonus</th>
                    <th className="py-3.5 px-4 text-center">Visits</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
                  {generatedLinks.map((link) => (
                    <tr key={link.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="py-3.5 px-4 font-sans font-bold text-slate-900">
                        {link.gameName}
                      </td>
                      <td className="py-3.5 px-4 text-indigo-600 font-semibold">
                        <div className="flex items-center gap-1.5 max-w-xs sm:max-w-md">
                          <span className="truncate select-all">{link.generatedLink}</span>
                          <button
                            onClick={() => copyToClipboard(link.generatedLink, link.id)}
                            className="p-1 hover:bg-slate-100 rounded text-slate-400 group-hover:text-slate-700 transition-colors shrink-0"
                            title="Copy link"
                          >
                            {copiedLinkId === link.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 font-semibold text-xs">
                        {link.referId}
                      </td>
                      <td className="py-3.5 px-4 text-indigo-600 font-extrabold">
                        ₹{link.bonusAmount}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded text-[11px] font-bold text-slate-800">
                          {link.clicks}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleSimulateClickAndDownload(link)}
                            className="p-1.5 bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-indigo-600 rounded-lg border border-slate-200 transition-colors flex items-center gap-1"
                            title="Simulate Referral Click Visit & Download"
                          >
                            <MousePointerClick className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={async () => {
                              try {
                                await deleteLinkFromDb(link.id);
                                const updated = generatedLinks.filter(l => l.id !== link.id);
                                saveLinks(updated);
                                showToast('Link removed from cloud history.');
                              } catch (err) {
                                showToast('❌ Failed to delete link from cloud.');
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <span className="text-lg leading-none font-sans">×</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xs text-slate-500 font-sans font-medium">No referral links created yet in this browser session.</p>
              <p className="text-[10px] text-slate-400 font-sans mt-0.5 font-medium">Use the generator above to instantly customize a short link.</p>
            </div>
          )}
        </section>

        {/* SECTION 4: ESTIMATED EARNINGS SLIDER CALCULATOR */}
        <section id="calculator" className="bg-white border border-slate-200 rounded-3xl p-8 grid md:grid-cols-12 gap-8 items-center shadow-xl shadow-slate-100">
          
          <div className="md:col-span-7 flex flex-col gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sliders className="w-5 h-5 text-indigo-600" />
                <h3 className="font-display font-extrabold text-lg text-slate-900">Yono Referral Earnings Calculator</h3>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Adjust sliders to estimate your referral commission based on the certified ₹50 - ₹100 sign-up bonus rates.
              </p>
            </div>

            <div className="flex flex-col gap-4 mt-2">
              {/* Slider 1: Referee counts */}
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-700 font-semibold">Expected Referrals</span>
                  <span className="text-indigo-600 font-bold text-sm bg-indigo-50 px-2.5 py-0.5 rounded border border-indigo-100">{referralCount} Players</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={referralCount}
                  onChange={(e) => setReferralCount(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-100 rounded-lg appearance-none"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono font-medium">
                  <span>1 Player</span>
                  <span>50 Players</span>
                  <span>100 Players</span>
                </div>
              </div>

              {/* Slider 2: Average bonus rate (50 to 100) */}
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-700 font-semibold">Average App Sign-up Bonus</span>
                  <span className="text-emerald-600 font-bold text-sm bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-100">₹{avgBonus}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={avgBonus}
                  onChange={(e) => setAvgBonus(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-100 rounded-lg appearance-none"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono font-medium">
                  <span>₹50 (Min)</span>
                  <span>₹75 (Avg)</span>
                  <span>₹100 (Max)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Calculate Result Box */}
          <div className="md:col-span-5 bg-gradient-to-br from-indigo-900 to-indigo-950 text-white p-6 rounded-2xl flex flex-col gap-4 shadow-xl">
            <span className="text-[10px] bg-white/15 text-indigo-200 border border-white/10 px-2.5 py-1 rounded-md font-bold uppercase tracking-wider self-start">
              Estimated Commission
            </span>

            <div>
              <span className="text-xs text-indigo-200 font-semibold block">Total Estimated Earnings</span>
              <span className="text-4xl font-extrabold text-white font-mono tracking-tight">₹{(referralCount * avgBonus).toLocaleString('en-IN')}</span>
            </div>

            <div className="h-[1px] bg-white/10" />

            <div className="flex flex-col gap-1.5 text-xs text-indigo-100">
              <div className="flex justify-between">
                <span>Expected Referrals:</span>
                <span className="font-bold">{referralCount} Players</span>
              </div>
              <div className="flex justify-between">
                <span>Avg App Bonus Value:</span>
                <span className="font-bold">₹{avgBonus}</span>
              </div>
              <div className="flex justify-between">
                <span>Network Multiplier:</span>
                <span className="text-amber-400 font-bold">1.5x Premium Active</span>
              </div>
            </div>

            <a
              href="#advance"
              className="w-full bg-white hover:bg-slate-100 text-indigo-950 font-bold text-xs py-3 rounded-xl transition-all text-center"
            >
              Access Advance Panel
            </a>
          </div>
        </section>

      </main>

      {/* Footer Stats */}
      <footer className="max-w-6xl mx-auto px-6 mt-12 pt-8 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex flex-wrap gap-12 text-center md:text-left">
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Active Members</div>
            <div className="text-xl font-extrabold text-slate-900">142,803</div>
          </div>
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Paid Out</div>
            <div className="text-xl font-extrabold text-slate-900">₹12.4M</div>
          </div>
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Current Multiplier</div>
            <div className="text-xl font-extrabold text-indigo-600">2.5x</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-slate-400 text-sm font-semibold">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
          Secure 256-bit Encrypted Payouts
        </div>
      </footer>
    </div>
  );
}
